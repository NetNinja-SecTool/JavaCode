import javax.swing.*;
import java.awt.*;

public interface book_master_main_Interface
{
	public book_master_info mast = new book_master_info();
    public JPanel master = new JPanel();
    public JPanel tab = new JPanel();
    public book_master_tab tabbed1 = new book_master_tab();
    public ImageIcon icon = new ImageIcon("");
    public JTabbedPane tabbedPane = new JTabbedPane();
}